﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
    //OBSERVE PATTERN

    public class NotifyMessag
    {
        //Creating array list for the messages
        public ArrayList MessNotify = new ArrayList();

        //Adding a message
        public void AddService(ICarFactory obj)
        {
            MessNotify.Add(obj);
        }

        //Removing a message
        public void RemoveService(ICarFactory obj)
        {
            MessNotify.Remove(obj);
        }

        //Method that will call the messages
        public void ExecuteNotify()
        {
            foreach(ICarFactory O in MessNotify)
            {
                //Call all notification System
                O.Notify();
            }
        }
    }
}
