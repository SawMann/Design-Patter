﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
   public class BWM : ICar
    {
        //FACTORY PATTERN

        //Here we create the Second Car in the project "CarProject"

        public string GetOnRoadName(string model)
        {
            if (model == "BMW")
            {
                return "X5";
            }
            else
            {
                return "Sorry but the information you are looking is missing.";
            }
        }
    }
}
