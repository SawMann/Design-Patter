﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
    //FACADE PATTERN

    //Creating a class that will be acssest anywere and here we create the car's parameters 

    internal class BWMCarParts
    {
        internal void AssembleTyre()
        {
            Console.WriteLine("Condition: New , not used");
        }

        internal void AssembleBody()
        {
            Console.WriteLine("Color:Black, Type:Джип - автоматик , Пробег - 0 КМ");
        }

        internal void AssembleEngine()
        {
            Console.WriteLine("BMW X5 ДИЗЕЛ");
        }

        internal void AssembleSeat()
        {
            Console.WriteLine("it has 7 seats");
        }

        internal void AssembleMusicSystem()
        {
            Console.WriteLine("Condition: Excelent, no need for changes");
        }
    }
}
