﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
    //FACTORY PATTERN

    //Creating the method for the second car which will creat a new "Second Car"

    public class BWMFactory :ICarFactory
    {
        public ICar GetCar()
        {
            return new BWM();
        }

        //Creating a message type

        public void Notify()
        {
            Console.WriteLine("Contact the user by SMS for the price.");
        }
    }
}
