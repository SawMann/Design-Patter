﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
    //FACADE PATTERN

    public class CarFacade
    {
        //Valuebles in the First Car

        AudiCarParts body, engin,tyre, accessories;

        //Valuebles for the Second Car

        BWMCarParts body2, engin2, tyre2, accessories2;

        //Declaring the valuebles

        public CarFacade()
        {
            body = new AudiCarParts();
            body2 = new BWMCarParts();
            engin = new AudiCarParts();
            engin2 = new BWMCarParts();
            tyre = new AudiCarParts();
            tyre2 = new BWMCarParts();
            accessories = new AudiCarParts();
            accessories2 = new BWMCarParts();

        }

        //Calling the methods from the "AudiCarParts"
        public void AssembleAudiCar()
        {
            Console.WriteLine("Assembling the car's model parameters");
            Console.WriteLine();
            body.AssembleBody();
            engin.AssembleEngine();
            tyre.AssembleTyre();
            accessories.AssembleMusicSystem();
            accessories.AssembleSeat();
            Console.WriteLine();
            Console.WriteLine("The assembling was complited.");
        }

        //Calling the method from the "BMWCarParts"
        public void AssembleBMWCar()
        {
            Console.WriteLine("Assembling the car's model parameters");
            Console.WriteLine();
            body2.AssembleBody();
            engin2.AssembleEngine();
            tyre2.AssembleTyre();
            accessories2.AssembleMusicSystem();
            accessories2.AssembleSeat();
            Console.WriteLine();
            Console.WriteLine("The assembling was complited.");
        }
    }
}
