﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
    //FACTORY PATTERN

    public class Audi : ICar
    {
        //Here we create the First Car in the "CarProject"

        public string GetOnRoadName(string model)
        {
            if (model == "Audi")
            {
                return "A4";
            }
            else
            {
                return "Sorry but the information you are looking is missing.";
            }
        }
    }
}
