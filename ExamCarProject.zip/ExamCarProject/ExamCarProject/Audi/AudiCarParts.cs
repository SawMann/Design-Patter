﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
    //FACADE PATTERN

    //Creating a class that will be acssest anywere and here we create the car's parameters 
   internal class AudiCarParts
    {
        internal void AssembleTyre()
        {
            Console.WriteLine("Condition: Used , advise - needs to be changed");
        }

        internal void AssembleBody()
        {
            Console.WriteLine("Color: Silver, Type: Лека кола, Евростандарт: Евро 4, Скоростна кутия: Ръчна, Категория: Седан, Пробег - 190421 КМ");
        }

        internal void AssembleEngine()
        {
            Console.WriteLine("Audi А4 Дизел");
        }

        internal void AssembleSeat()
        {
            Console.WriteLine("It has 4 seats");
        }

        internal void AssembleMusicSystem()
        {
            Console.WriteLine("Condition: Not very good, needs changes");
        }
    }
}
