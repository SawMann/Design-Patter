﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
    //FACTORY PATTERN

    //Creating a method for the fist car that will creat a new "First Car"
   public class AudiFactory : ICarFactory
    {
        public ICar GetCar()
        {
            return new Audi();
        }

        //Creating a message type
        public void Notify()
        {
            Console.WriteLine("Contact the user by Е-Mail for the price.");
        }

    }
}
