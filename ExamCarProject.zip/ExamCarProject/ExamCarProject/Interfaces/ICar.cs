﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
    //FACTORY PATTERN
    //Creating the interface that takes the names of the car

    public interface ICar
    {
        string GetOnRoadName(string model);
    }
}
