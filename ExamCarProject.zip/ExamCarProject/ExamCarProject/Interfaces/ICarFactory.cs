﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
    //FACTORY PATTERN AND OBSERVE PATTERN (void Notify)

    //Creating the interface that will call in the GetGar method and the Notify method

   public interface ICarFactory
    {
        ICar GetCar();
        void Notify();
    }
}
