﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamCarProject
{
    class Program
    {

        //Using all 3 pattern's

        static void Main(string[] args)
        {
            //Creating empty variables

            Console.WriteLine("Begining the Car Information Bord.");
            Console.ReadLine();
            ICarFactory carFactory = null;
            ICar car = null;
            string model = null;
            CarFacade carFacade = new CarFacade();

            //Throwing an Exception to call in the Messages(Notifications)
            try
            {
                throw new ApplicationException("This is Exception");

            }
            catch (Exception ex)
            {
                ICarFactory obj1 = new AudiFactory();
                ICarFactory obj2 = new BWMFactory();
                NotifyMessag O = new NotifyMessag();

                //Giving value to the variables - Factory Pattern
                carFactory = new AudiFactory();
                car = carFactory.GetCar();
                model = "Audi";
                Console.WriteLine("The car that will show on the console is {0}, and it's model is : {1}", model, car.GetOnRoadName(model));
                Console.ReadLine();

                //Calling the Facade Pattern
                carFacade.AssembleAudiCar();
                Console.ReadLine();

                //Calling the Observe Patter
                O.AddService(obj1);
                //Executing the Obser Pattern
                O.ExecuteNotify();
                Console.ReadLine();

                //Giving values to the variables - Factory Pattern
                carFactory = new BWMFactory();
                car = carFactory.GetCar();
                model = "BMW";
                Console.WriteLine("The car that will show on the console is {0}, and it's model is : {1}", model, car.GetOnRoadName(model));
                Console.ReadLine();

                //Calling the Facade Patter
                carFacade.AssembleBMWCar();
                Console.ReadLine();

                //Calling the Observe Patter
                O.AddService(obj2);
                //Executing the Observe Patter
                O.ExecuteNotify();
                Console.ReadLine();
                
            }
            Console.ReadLine();
            Console.WriteLine("The CarProject was complited");    
        }
    }
}
